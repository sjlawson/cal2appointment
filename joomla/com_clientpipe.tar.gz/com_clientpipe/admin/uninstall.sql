DROP TABLE IF EXISTS `#__cp_clientpipe`;
DROP TABLE IF EXISTS `#__cp_slot`;
Drop TABLE IF EXISTS `#__cp_exception`;
DROP TABLE IF EXISTS `#__cp_slot_alloc`;
DROP TABLE IF EXISTS `#__cp_staff`;
DROP TABLE IF EXISTS `#__cp_event`;
DROP TABLE IF EXISTS `#__cp_options`;
DROP TABLE IF EXISTS `#__cp_appointment`;