<?php
/**
 * Clientpipe World default controller
 * 
 * @package    SteamPower.ClientPipe
 * @subpackage Components
 * @link http://sjlawson.sdf.org/steampower
 * @license		GNU/GPL
 */

jimport('joomla.application.component.controller');

/**
 * Clientpipe World Component Controller
 *
 * @package		ClientpipeWorld
 */
class ClientpipeController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		
		parent::display();
	}
	
	function save() {
		die(var_dump(JFactory::getApplication()->input));
	}

}
?>
